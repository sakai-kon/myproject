/**
 * 飛騨防災ガイド - 共通スクリプト
 * ヘッダー制御 / ダークモード / スクロールアニメーション /
 * モバイルメニュー / アコーディオン / チェックリスト保存
 * すべて ES6+, グローバル変数を持たないモジュールパターンで実装。
 */
(() => {
  'use strict';

  /* ---------------- Header: scroll state ---------------- */
  const initHeader = () => {
    const header = document.querySelector('.site-header');
    if (!header) return;
    const onScroll = () => {
      header.classList.toggle('is-scrolled', window.scrollY > 12);
    };
    onScroll();
    window.addEventListener('scroll', onScroll, { passive: true });
  };

  /* ---------------- Mobile hamburger menu ---------------- */
  const initMobileMenu = () => {
    const toggle = document.querySelector('[data-menu-toggle]');
    const menu = document.querySelector('[data-mobile-menu]');
    const burger = document.querySelector('.burger');
    if (!toggle || !menu) return;

    toggle.addEventListener('click', () => {
      const isOpen = menu.classList.toggle('is-open');
      burger?.classList.toggle('is-open', isOpen);
      toggle.setAttribute('aria-expanded', String(isOpen));
    });

    menu.querySelectorAll('a').forEach((link) => {
      link.addEventListener('click', () => {
        menu.classList.remove('is-open');
        burger?.classList.remove('is-open');
        toggle.setAttribute('aria-expanded', 'false');
      });
    });
  };

  /* ---------------- Dark mode ---------------- */
  const THEME_KEY = 'hida-bousai-theme';

  const applyTheme = (theme) => {
    document.documentElement.setAttribute('data-theme', theme);
    document.querySelectorAll('[data-theme-toggle]').forEach((btn) => {
      btn.setAttribute('aria-pressed', String(theme === 'dark'));
    });
  };

  const initTheme = () => {
    const stored = localStorage.getItem(THEME_KEY);
    const prefersDark = window.matchMedia('(prefers-color-scheme: dark)').matches;
    applyTheme(stored || (prefersDark ? 'dark' : 'light'));

    document.querySelectorAll('[data-theme-toggle]').forEach((btn) => {
      btn.addEventListener('click', () => {
        const next = document.documentElement.getAttribute('data-theme') === 'dark' ? 'light' : 'dark';
        applyTheme(next);
        localStorage.setItem(THEME_KEY, next);
      });
    });
  };

  /* ---------------- Scroll reveal animations ---------------- */
  const initReveal = () => {
    const items = document.querySelectorAll('.reveal, .reveal-zoom');
    if (!items.length) return;

    if (!('IntersectionObserver' in window)) {
      items.forEach((el) => el.classList.add('is-visible'));
      return;
    }

    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            entry.target.classList.add('is-visible');
            observer.unobserve(entry.target);
          }
        });
      },
      { threshold: 0.15, rootMargin: '0px 0px -40px 0px' }
    );

    items.forEach((el) => observer.observe(el));
  };

  /* ---------------- FAQ accordion ---------------- */
  const initAccordion = () => {
    document.querySelectorAll('.accordion-item').forEach((item) => {
      const trigger = item.querySelector('.accordion-trigger');
      const panel = item.querySelector('.accordion-panel');
      if (!trigger || !panel) return;

      trigger.addEventListener('click', () => {
        const isOpen = item.getAttribute('data-open') === 'true';
        item.setAttribute('data-open', String(!isOpen));
        trigger.setAttribute('aria-expanded', String(!isOpen));
        panel.style.maxHeight = !isOpen ? `${panel.scrollHeight}px` : '0px';
      });
    });
  };

  /* ---------------- Checklist persistence (localStorage) ---------------- */
  const CHECKLIST_KEY = 'hida-bousai-checklist';

  const initChecklist = () => {
    const boxes = document.querySelectorAll('[data-check-id]');
    if (!boxes.length) return;

    let saved = {};
    try {
      saved = JSON.parse(localStorage.getItem(CHECKLIST_KEY)) || {};
    } catch (err) {
      saved = {};
    }

    const updateProgress = () => {
      const total = boxes.length;
      const checked = Array.from(boxes).filter((b) => b.checked).length;
      const bar = document.querySelector('[data-check-progress-bar]');
      const label = document.querySelector('[data-check-progress-label]');
      if (bar) bar.style.width = `${total ? Math.round((checked / total) * 100) : 0}%`;
      if (label) label.textContent = `${checked} / ${total} 完了`;
    };

    boxes.forEach((box) => {
      const id = box.dataset.checkId;
      if (saved[id]) box.checked = true;
      box.addEventListener('change', () => {
        saved[box.dataset.checkId] = box.checked;
        localStorage.setItem(CHECKLIST_KEY, JSON.stringify(saved));
        updateProgress();
      });
    });

    updateProgress();
  };

  /* ---------------- Learning notes (content.txt) ---------------- */
  const initLearningNotes = () => {
    const target = document.getElementById('learning-content');
    if (!target) return;

    fetch('content.txt')
      .then((res) => {
        if (!res.ok) throw new Error('failed to load');
        return res.text();
      })
      .then((text) => {
        target.textContent = text;
      })
      .catch(() => {
        target.textContent = '学習テキスト（content.txt）の読み込みに失敗しました。ファイルが正しい場所に保存されているか確認してください。';
      });
  };

  /* ---------------- Init on DOM ready ---------------- */
  document.addEventListener('DOMContentLoaded', () => {
    initHeader();
    initMobileMenu();
    initTheme();
    initReveal();
    initAccordion();
    initChecklist();
    initLearningNotes();
  });
})();
